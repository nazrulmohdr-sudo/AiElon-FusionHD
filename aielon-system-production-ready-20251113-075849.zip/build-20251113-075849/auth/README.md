Auth: JWT + OAuth2
