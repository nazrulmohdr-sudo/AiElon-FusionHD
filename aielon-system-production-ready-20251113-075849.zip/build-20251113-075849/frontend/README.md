Frontend: React + FusionHD
